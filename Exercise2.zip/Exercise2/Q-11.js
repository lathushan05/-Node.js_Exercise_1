var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("student");
  var raam = {"name" : "Raam"};
  var del = {$unset: {"science_marks" : 88}};
  dbo.collection("​studentmarks").updateOne(raam, del, function(err, res) {
    if (err) throw err;
    console.log(res.result.nModified + "Deleted");
    db.close();
  });
});
