var http = require('http');
var sample = require('./Q-1-0.js');

http. createServer(function (req, res) {
  res.writeHead(200, {'Content-Type': 'text/html'});
  res.write(`Sum Number = ${sample.sumNum(123, 321)}`);
  res.write(`Average Number = ${sample.average(123, 321)}`);
  res.end();
}).listen(8080);
